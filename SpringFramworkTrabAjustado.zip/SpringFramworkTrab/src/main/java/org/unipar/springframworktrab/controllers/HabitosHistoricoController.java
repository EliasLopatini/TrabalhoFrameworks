package org.unipar.springframworktrab.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;
import org.unipar.springframworktrab.domain.Habitos_Historico;
import org.unipar.springframworktrab.service.HabitosHistoricoService;

import java.net.URI;
import java.util.List;
@RestController
@RequestMapping("/habitosHistorico")
public class HabitosHistoricoController {

    private final HabitosHistoricoService habitosHistoricoService;

    @Autowired
    public HabitosHistoricoController(HabitosHistoricoService habitosHistoricoService) {
        this.habitosHistoricoService = habitosHistoricoService;
    }

    @PostMapping
    public ResponseEntity<Habitos_Historico> adicionarHistorico(@RequestBody Habitos_Historico habitosHistorico) {
        Habitos_Historico novoHistorico = habitosHistoricoService.salvarHistorico(habitosHistorico);
        return new ResponseEntity<>(novoHistorico, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<Habitos_Historico>> listarHistorico() {
        List<Habitos_Historico> historico = habitosHistoricoService.listarHistorico();
        return new ResponseEntity<>(historico, HttpStatus.OK);
    }
}