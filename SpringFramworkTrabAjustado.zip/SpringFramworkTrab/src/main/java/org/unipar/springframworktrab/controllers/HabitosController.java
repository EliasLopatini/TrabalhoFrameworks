package org.unipar.springframworktrab.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;
import org.unipar.springframworktrab.domain.Habitos;
import org.unipar.springframworktrab.exceptions.ApiException;
import org.unipar.springframworktrab.service.HabitosService;

import java.net.URI;
import java.util.List;
@RestController
@RequestMapping("/habitos")
public class HabitosController {

    @Autowired
    private HabitosService habitosService;

    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Ok", content =
                    { @Content(mediaType = "application/json", schema =
                    @Schema(implementation = Habitos.class)) }),
            @ApiResponse(responseCode = "400", description = "ID inválido informado"),
            @ApiResponse(responseCode = "404", description = "Hábito não encontrado"),
            @ApiResponse(responseCode = "500", description = "Erro interno do servidor") })
    @Operation(summary = "GET BY ID Hábito", description = "Busca o hábito por ID", tags = "Hábito")
    @GetMapping("/{id}")
    public ResponseEntity<Habitos> findById(@PathVariable Long id) {
        return ResponseEntity.ok(habitosService.findById(id));
    }

    @Operation(summary = "FIND ALL Hábitos", description = "Busca todos os hábitos", tags = "Hábito")
    @GetMapping
    public List<Habitos> findAll() {
        return habitosService.findAll();
    }

    @Operation(summary = "INSERT Hábito", description = "Insere um novo hábito", tags = "Hábito")
    @PostMapping
    public ResponseEntity<Habitos> save(@RequestBody @Valid Habitos habitos, UriComponentsBuilder builder) {
        habitosService.save(habitos);
        URI uri = builder.path("/habitos/{id}").buildAndExpand(habitos.getId()).toUri();
        return ResponseEntity.created(uri).body(habitos);
    }

    @Operation(summary = "UPDATE Hábito", description = "Atualiza um hábito existente", tags = "Hábito")
    @PutMapping("/{id}")
    public ResponseEntity<Habitos> update(@PathVariable Long id, @RequestBody Habitos habitosDetails) {
        Habitos updatedHabitos = habitosService.update(id, habitosDetails);
        return updatedHabitos != null ? ResponseEntity.ok(updatedHabitos) : ResponseEntity.notFound().build();
    }

    @Operation(summary = "DELETE Hábito", description = "Deleta um hábito", tags = "Hábito")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        habitosService.delete(id);
        return ResponseEntity.noContent().build();
    }
}