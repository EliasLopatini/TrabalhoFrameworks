package org.unipar.springframworktrab.domain;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.sql.Timestamp;

@Getter
@Setter
@Entity
@Table(name = "TAREFAS")
public class Tarefas {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotBlank(message = "A descrição não pode estar em branco.")
    private String descricao;

    @NotNull(message = "A data de início não pode ser nula.")
    private Timestamp data_inicio;


    private Timestamp data_fim;

    private boolean concluida;



    // Construtor com parâmetros
    public Tarefas(long id, String descricao, Timestamp data_inicio, Timestamp data_fim,
                   boolean concluida) {
        this.id = id;
        this.descricao = descricao;
        this.data_inicio = data_inicio;
        this.data_fim = data_fim;
        this.concluida = concluida;

    }

    // Construtor padrão
    public Tarefas() {
    }
}