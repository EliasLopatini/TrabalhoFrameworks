package org.unipar.springframworktrab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringFramworkTrabApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringFramworkTrabApplication.class, args);
	}

}
