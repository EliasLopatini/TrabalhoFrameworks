package org.unipar.springframworktrab.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.unipar.springframworktrab.domain.Tarefas;
import org.unipar.springframworktrab.repositories.TarefasRepository;

import java.sql.Timestamp;
import java.util.List;

@Service
public class TarefasService {

    @Autowired
    private TarefasRepository tarefasRepository;

    public List<Tarefas> listarTarefas() {
        return tarefasRepository.findAll();
    }

    public Tarefas salvarTarefa(Tarefas tarefa) {
        return tarefasRepository.save(tarefa);
    }

    public Tarefas atualizarStatus(Long id, boolean concluida, Timestamp dataFim) {
        Tarefas tarefa = tarefasRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Tarefa não encontrada"));
        tarefa.setConcluida(concluida);
        tarefa.setData_fim(dataFim);
        return tarefasRepository.save(tarefa);
    }
}