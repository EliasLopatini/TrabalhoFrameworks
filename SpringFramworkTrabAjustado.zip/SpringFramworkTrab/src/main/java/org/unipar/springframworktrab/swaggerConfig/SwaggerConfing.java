package org.unipar.springframworktrab.swaggerConfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;


@Configuration
public class SwaggerConfing {

    @Bean
    public OpenAPI customAPI() {
        return new OpenAPI().info(new Info().title("ACADEMY CONTROLL").version("1.0.0")
                .license(new License().name("ALUNO: RENATO DA CRUZ XAVIER  RA:238660-1 \n" +
                        "ALUNO: ELIAS ANTONIO LOPATINI GASPERIN RA:236544-1\n"+
                        "ALUNO: GABRIEL WICTOR HEIDRICH RA: 232714-1")));
    }
}
