package org.unipar.springframworktrab.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.unipar.springframworktrab.domain.Habitos_Historico;

public interface HabitosHistoricoRepository extends JpaRepository<Habitos_Historico,Long> {



}
