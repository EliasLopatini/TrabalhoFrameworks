    package org.unipar.springframworktrab.domain;

    import jakarta.persistence.*;
    import jakarta.validation.constraints.NotBlank;
    import jakarta.validation.constraints.NotEmpty;
    import jakarta.validation.constraints.NotNull;
    import lombok.Getter;
    import lombok.Setter;

    @Setter
    @Getter
    @Entity
    @Table(name ="USUARIO")
    public class Usuario {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private long id;

        @NotBlank
        @NotNull
        @NotEmpty
        private String nome;
        @NotBlank
        @NotNull
        @NotEmpty
        private String email;
        @NotBlank
        @NotNull
        @NotEmpty
        private String senha;

        public Usuario(long id, String nome, String email, String senha) {
            this.id = id;
            this.nome = nome;
            this.email = email;
            this.senha = senha;
        }

        public Usuario() {
        }
    }
