package org.unipar.springframworktrab.domain;


import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
@Entity
@Table(name = "HABITOS_HISTORICO")
public class Habitos_Historico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    @NotNull
    private Date titulo;  // Garante que a data não seja nula

    @ManyToOne
    @JoinColumn(name = "habito_id", nullable = false)
    private Habitos habito;

    public Habitos_Historico(long id, Date titulo, Habitos habito) {
        this.id = id;
        this.titulo = titulo;
        this.habito = habito;
    }

    public Habitos_Historico() {
    }
}