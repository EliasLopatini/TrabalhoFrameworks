package org.unipar.springframworktrab.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.unipar.springframworktrab.domain.Habitos;
import org.unipar.springframworktrab.repositories.HabitosRepository;

import java.util.List;

@Service
public class HabitosService {

    @Autowired
    private HabitosRepository habitosRepository;

    public Habitos findById(Long id) {
        return habitosRepository.findById(id).orElseThrow(() -> new RuntimeException("Hábito não encontrado"));
    }

    public List<Habitos> findAll() {
        return habitosRepository.findAll();
    }

    public Habitos save(Habitos habitos) {
        return habitosRepository.save(habitos);
    }

    public Habitos update(Long id, Habitos habitosDetails) {
        Habitos habitos = findById(id);
        habitos.setDescricao(habitosDetails.getDescricao());
        return habitosRepository.save(habitos);
    }

    public void delete(Long id) {
        Habitos habitos = findById(id);
        habitosRepository.delete(habitos);
    }
}