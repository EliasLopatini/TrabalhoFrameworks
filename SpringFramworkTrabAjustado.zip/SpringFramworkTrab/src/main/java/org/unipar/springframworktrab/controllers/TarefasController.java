package org.unipar.springframworktrab.controllers;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;
import org.unipar.springframworktrab.domain.Tarefas;
import org.unipar.springframworktrab.service.TarefasService;

import java.net.URI;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/tarefas")
public class TarefasController {

    @Autowired
    private TarefasService tarefaService;

    @GetMapping
    public List<Tarefas> listarTarefas() {
        return tarefaService.listarTarefas();
    }

    @PostMapping
    public ResponseEntity<Tarefas> adicionarTarefa(@RequestBody Tarefas tarefa) {
        // Deixe data_fim como null se a tarefa não estiver concluída
        if (!tarefa.isConcluida()) {
            tarefa.setData_fim(null);
        }

        try {
            Tarefas novaTarefa = tarefaService.salvarTarefa(tarefa);
            return ResponseEntity.ok(novaTarefa);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(null); // Retorna erro se algo falhar
        }
    }

    @PutMapping("/{id}")
    public Tarefas atualizarStatus(@PathVariable Long id, @RequestBody Map<String, Object> payload) {
        boolean concluida = (boolean) payload.get("concluida");
        Timestamp dataFim = concluida ? new Timestamp(System.currentTimeMillis()) : null;
        return tarefaService.atualizarStatus(id, concluida, dataFim);
    }
}