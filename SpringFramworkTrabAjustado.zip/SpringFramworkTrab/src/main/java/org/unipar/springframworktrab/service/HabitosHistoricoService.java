package org.unipar.springframworktrab.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.unipar.springframworktrab.domain.Habitos_Historico;
import org.unipar.springframworktrab.repositories.HabitosHistoricoRepository;

import java.util.List;

@Service
public class HabitosHistoricoService {

    @Autowired
    private HabitosHistoricoRepository habitosHistoricoRepository;

    public Habitos_Historico salvarHistorico(Habitos_Historico habitosHistorico) {
        return habitosHistoricoRepository.save(habitosHistorico);
    }

    public List<Habitos_Historico> listarHistorico() {
        return habitosHistoricoRepository.findAll();
    }
}