package org.unipar.springframworktrab.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.unipar.springframworktrab.domain.Habitos;

public interface HabitosRepository extends JpaRepository<Habitos,Long> {
}
