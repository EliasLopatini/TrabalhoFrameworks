package org.unipar.springframworktrab.domain;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
@Table(name = "HABITOS")
public class Habitos {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;
    @NotBlank
    @NotNull
    @NotEmpty
    private String descricao;

    public Habitos(long id, String descricao) {
        this.id = id;
        this.descricao = descricao;
    }

    public Habitos() {
    }
}
